package org.example.acc;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;

public class ChangeDataCaptureStepDef {
	
	String baseFileName;
	String deltaFileName;
	String outputFileFolder;
	String firstKeyPair;
	Dataset<Row> actualOutput;
	
	@Given("^there is a data file \"([^\"]*)\" with loan data$")
	public void there_is_a_data_file_with_loan_data(String arg1) throws Throwable {
		baseFileName=arg1;

	}

	@Given("^there is a file with delta transaction named as \"([^\"]*)\"$")
	public void there_is_a_file_with_delta_transaction_named_as(String arg1) throws Throwable {
		deltaFileName = arg1;

	}

	
	@When("^I execute ETL process for change data capture$")
	public void i_execute_ETL_process_for_change_data_capture() throws Throwable {

		actualOutput = App.scdtype11(baseFileName, deltaFileName);
		System.out.println("************** Result dataframe *******************");
		actualOutput.show();

	}
	
	@Then("^I should get only three results in actual outfile$")
	public void i_should_get_only_three_results_in_actual_outfile() throws Throwable {
		assert actualOutput.count() == 3;

	}
	
	@Then("^It should have value loan number as (\\d+) for \"([^\"]*)\"$")
	public void it_should_have_value_loan_number_as_for(int arg1, String arg2) throws Throwable {
		
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg1); //filtering results based on employee ID
		
		String output = df.collectAsList().toString();
		
		Assert.assertTrue(output.contains("Jessie"));
		System.out.println("Record for Jessie");
//		Assert.assertTrue(output.contains("42000"));
//		
//		Assert.assertTrue(output.contains("Brisbane"));

	
	}

	@Then("^EndDate for \"([^\"]*)\" should be \"([^\"]*)\"$")
	public void enddate_for_should_be(String arg1, String arg2) throws Throwable {
		
		Dataset<Row> df = actualOutput.where(actualOutput.col("LOAN_NUMBER").contains(arg1));
		
	//	Dataset<Row> df = actualOutput.select("emp_city").where("NEXT_PMT_DUE_DATE");
		
	//	Dataset<Row> df = actualOutput.filter("LOAN_NUMBER ==5");
		df.show();
		
	//	Dataset<Row> df = actualOutput.filter("NEXT_PMT_DUE_DATE =='"+arg1+"'"); //filtering results based on employee name
		
		String output = df.collectAsList().toString();
		System.out.println("End date::::" + output);
		
		Assert.assertTrue(output.contains(arg2));


	}

	@Then("^NextPaydate for \"([^\"]*)\" should be \"([^\"]*)\"$")
	public void nextpaydate_for_should_be(String arg1, String arg2) throws Throwable {
		
	//	Dataset<Row> df = actualOutput.filter(col("LOAN_NUMBER").gt(5)).show();
	//		Dataset<Row> df = actualOutput.filter("NEXT_PMT_DUE_DATE =="+"Jessie"+"");
		
	//	Dataset<Row> df = actualOutput.filter("NEXT_PMT_DUE_DATE =='"+arg1+"'"); //filtering results based on employee name
		
		Dataset<Row> df = actualOutput.where(actualOutput.col("NEXT_PMT_DUE_DATE").contains(arg1));

		String output = df.collectAsList().toString();
			
		System.out.println("EFF_DT::::" + output);

		Assert.assertTrue(output.contains(arg2));

	}

	

	@Then("^It should match expected output file named as \"([^\"]*)\"$")
	public void it_should_match_expected_output_file_named_as(String arg1) throws Throwable {
//		Dataset<Row> dfExpectedOutput = App.CsvToDatasetToDataframe(arg1);
//		dfExpectedOutput.show();
		
		actualOutput.show();
		
		
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER == 5");
		
		String output = df.collectAsList().toString();
		
		System.out.println("Salary::::" + output);
		
		Assert.assertTrue(output.contains("Jessie"));
		
		Assert.assertTrue(output.contains("42000"));
		
		Assert.assertTrue(output.contains("Brisbane"));
		
//		
//		System.out.println("Salary::::" + output.get(0));
	
//		System.out.println("Salary::::" + df.collectAsList().toString());
//		System.out.println("Name::::" + df.col("NEXT_PMT_DUE_DATE").toString());
	//	df.show();


		 
	//	System.out.println("union COUNT::::"+dfExpectedOutput.union(actualOutput).distinct().count());
	//	System.out.println("intersect COUNT::::"+dfExpectedOutput.intersect(actualOutput).count());
	//	assert dfExpectedOutput.union(actualOutput).distinct().count() == dfExpectedOutput.intersect(actualOutput).count();
	}


	@Then("^I should get only four results in actual outfile$")
	public void iShouldGetOnlyFourResultsInActualOutfile() {
		assert actualOutput.count() == 4;
	}


	@And("^It should have the value LOAN_NUMBER as (\\d+) for \"([^\"]*)\"$")
	public void itShouldHaveTheValueLOAN_NUMBERAsFor(int arg0, String arg1) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg0); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg1));
	}



	@And("^Previous End Date for \"([^\"]*)\" should be \"([^\"]*)\" for iscurrent as \"([^\"]*)\"$")
	public void previousEndDateForShouldBe(String arg0, String arg1, String arg2) throws Throwable {
		Dataset<Row> df = actualOutput.where(actualOutput.col("END_DT").contains(arg0))
							.where(actualOutput.col("IS_CURRENT").contains(arg2));
		String output = df.collectAsList().toString();
		System.out.println("Previous End date::::" + output);
		Assert.assertTrue(output.contains(arg1));
	}



	@When("^I execute ETL process for change data typetwo capture$")
	public void iExecuteETLProcessForChangeDataTypetwoCapture() throws IOException {
		actualOutput = App.scdtype22(baseFileName, deltaFileName);
		System.out.println("************** Result dataframe *******************");
		actualOutput.show();
	}




	@Then("^NEXT_PMT_DUE_DATE for LOAN_NUMBER as (\\d+) should be \"([^\"]*)\" for iscurrent as \"([^\"]*)\"$")
	public void NEXT_PMT_DUE_DATEForLOAN_NUMBERAsShouldBeForIscurrentAs(int arg0, String arg1, String arg2) throws Throwable {
		Dataset<Row> df = actualOutput.where(actualOutput.col("LOAN_NUMBER").contains(arg0))
				.where(actualOutput.col("is_current").contains(arg2));
		String output = df.collectAsList().toString();
		System.out.println("Updated Record"+output);
		Assert.assertTrue(output.contains(arg1));

	}


	@And("^It should have value principal balance of loan number for (\\d+) as \"([^\"]*)\"$")
	public void itShouldHaveValuePrincipalBalanceOfLoanNumberForArgAs(int arg0, String arg1) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg0); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg1));
		System.out.println("Record for Loan No. 123");
	}


	@And("^It should have the value eff dt as \"([^\"]*)\" end dt as \"([^\"]*)\" for loan number (\\d+)$")
	public void itShouldHaveTheValueEffDtAsEndDtAsForLoanNumberArg(String arg0, String arg1, int arg2) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg2); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg0));
		Assert.assertTrue(output.contains(arg1));
		System.out.println("Record for Loan No. 567");
	}

	@And("^It should have the value eff dt as \"([^\"]*)\" for loan number (\\d+)$")
	public void itShouldHaveTheValueEffDtAsForLoanNumberArg(String arg0, int arg1) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg1); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg0));
		System.out.println("Record for Loan No. 567 Effective date"+output);
	}

	@Then("^The principal balance should be \"([^\"]*)\" for loan number (\\d+)$")
	public void thePrincipalBalanceShouldBeForLoanNumberArg(String arg0, int arg1) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg1); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg0));
		System.out.println("Record for Loan No. 567 Balance"+output);
	}

	@And("^The End date for loan number (\\d+) should be \"([^\"]*)\"$")
	public void theEndDateForLoanNumberArgShouldBe(int arg0, String arg1) throws Throwable {
		Dataset<Row> df = actualOutput.filter("LOAN_NUMBER =="+arg0); //filtering results based on employee ID
		String output = df.collectAsList().toString();
		Assert.assertTrue(output.contains(arg1));
		System.out.println("Record for Loan No. 567 End date"+output);
	}


	@Then("^Previous End Date for loan number (\\d+) should be \"([^\"]*)\" for iscurrent as \"([^\"]*)\"$")
	public void previousEndDateForLoanNumberArgShouldBeForIscurrentAs(int arg0, String arg1, String arg2) throws Throwable {
		Dataset<Row> df = actualOutput.where(actualOutput.col("LOAN_NUMBER").contains(arg0))
				.where(actualOutput.col("IS_CURRENT").contains(arg2));
		String output = df.collectAsList().toString();
		System.out.println("Updated Record"+output);
		Assert.assertTrue(output.contains(arg1));
	}

	@And("^Updated End Date for loan number (\\d+) should be \"([^\"]*)\" for iscurrent as \"([^\"]*)\"$")
	public void updatedEndDateForLoanNumberArgShouldBeForIscurrentAs(int arg0, String arg1, String arg2) throws Throwable {
		Dataset<Row> df = actualOutput.where(actualOutput.col("LOAN_NUMBER").contains(arg0))
				.where(actualOutput.col("IS_CURRENT").contains(arg2));
		String output = df.collectAsList().toString();
		System.out.println("Updated Record"+output);
		Assert.assertTrue(output.contains(arg1));
	}
}