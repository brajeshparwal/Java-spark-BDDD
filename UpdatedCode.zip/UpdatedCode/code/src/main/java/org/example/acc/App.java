package org.example.acc;
import static org.apache.spark.sql.functions.current_date;
import static org.apache.spark.sql.functions.lit;

import java.io.IOException;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;


public class App
{
      public static void main (String[]args) throws InterruptedException, IOException {

          SparkSession session = SparkSession
                  .builder()
                  .appName("SparkJavaExample")
                  .master("local")
                  .getOrCreate();
          
          Dataset<Row> basecsv, deltacsv;
          basecsv = session.read().format("csv")
                  .option("sep", ",")
                  .option("inferSchema", "true")
                  .option("header", "true")
                  .load("src/main/resources/loan_base_data.csv");
          basecsv.show();
          basecsv.printSchema();

          deltacsv = session.read().format("csv")
                  .option("sep", ",")
                  .option("inferSchema", "true")
                  .option("header", "true")
                  .load("src/main/resources/loan_delta_data.csv");
          deltacsv.show();
          deltacsv.printSchema();
          
//          System.out.println(" SCD Type 1 ");
//          scdtype1(session,basecsv,deltacsv);
//          
          System.out.println(" SCD Type 2 ");
          scdtype2(session,basecsv,deltacsv);

          session.stop();
      }

    public static void scdtype1(SparkSession session, Dataset<Row> basecsv, Dataset<Row> deltacsv) throws IOException {
              Dataset<Row>  innerjoindf, leftjoindf, rightjoindf, updateddf;
              innerjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "inner").select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                      deltacsv.col("PROCESS_DT")); //inner join
              innerjoindf.show();

              leftjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "left_outer").filter(deltacsv.col("LOAN_NUMBER").isNull()).select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"),
                      basecsv.col("PRINCIPAL_BALANCE"), basecsv.col("PROCESS_DT"));
              //.withColumn("Curr_date",lit("Updated"))
              leftjoindf.show();

              rightjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "right_outer").filter(basecsv.col("LOAN_NUMBER").isNull()).select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                      deltacsv.col("PROCESS_DT"));
              rightjoindf.show();
              updateddf = leftjoindf.union(innerjoindf.union(rightjoindf));
              System.out.println("The updated dataframe");
              updateddf.show();
          //    updateddf.coalesce(1).write().mode("overwrite").option("header", "true").option("sep", ",").csv("src/main/resources/emptype1/");


    }

    public static void scdtype2(SparkSession session, Dataset<Row> basecsv, Dataset<Row> deltacsv) throws IOException {
        Dataset<Row>  ijupdatedf, ijexistdf, leftjoindf, rightjoindf, updateddf;
        ijupdatedf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "inner").select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                deltacsv.col("PROCESS_DT")).withColumn("is_current",lit("Y")); //inner join updated records
        ijupdatedf.show();

        ijexistdf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "inner").select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"), basecsv.col("PRINCIPAL_BALANCE"),
                basecsv.col("PROCESS_DT")).withColumn("is_current",lit("N")); //inner join existing records
        ijexistdf.show();

        leftjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "left_outer").filter(deltacsv.col("LOAN_NUMBER").isNull()).select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"),
                basecsv.col("PRINCIPAL_BALANCE"), basecsv.col("PROCESS_DT")).withColumn("is_current",lit("Y"));  //unchanged records
        //.withColumn("Curr_date",lit("Updated"))
        leftjoindf.show();

        rightjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER").equalTo(deltacsv.col("LOAN_NUMBER")), "right_outer").filter(basecsv.col("LOAN_NUMBER").isNull()).select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                deltacsv.col("PROCESS_DT")).withColumn("is_current",lit("Y")); //new records
        rightjoindf.show();
        updateddf = leftjoindf.union(ijexistdf.union(rightjoindf.union(ijupdatedf)));
        System.out.println("The updated dataframe");
        updateddf.show();
       // updateddf.coalesce(1).write().mode("overwrite").option("header", "true").option("sep", ",").csv("src/main/resources/emptype2/");


    }
    
    public static Dataset<Row> scdtype11(String basecsvlocation, String deltacsvlocation) throws IOException {
    	
        SparkSession session = SparkSession
                .builder()
                .appName("SparkJavaExample")
                .master("local")
                .getOrCreate();
        
        Dataset<Row> basecsv, deltacsv;
        basecsv = session.read().format("csv")
                .option("sep", ",")
                .option("inferSchema", "true")
                .option("header", "true")
                .load("src/main/resources/"+basecsvlocation);
             //   .load("src/main/resources/loan_base_data.csv");
        basecsv.show();
        basecsv.printSchema();

        deltacsv = session.read().format("csv")
                .option("sep", ",")
                .option("inferSchema", "true")
                .option("header", "true")
                .load("src/main/resources/"+deltacsvlocation);
        deltacsv.show();
        deltacsv.printSchema();
    	
        Dataset<Row>  innerjoindf, leftjoindf, rightjoindf, updateddf;
        innerjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                        .equalTo(deltacsv.col("LOAN_NUMBER")), "inner") 
                        .select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE")
                                , deltacsv.col("PRINCIPAL_BALANCE")
                , deltacsv.col("PROCESS_DT").alias("EFF_DT"))
                //.withColumn("EFF_DT" , deltacsv.("PROCESS_DT"))
                        .withColumn("END_DT",lit("16-06-2295"));
                        //deltacsv.col("PROCESS_DT")); //inner join
        innerjoindf.show();

        leftjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "left_outer")
                .filter(deltacsv.col("LOAN_NUMBER").isNull())
                .select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"),
                basecsv.col("PRINCIPAL_BALANCE"), basecsv.col("PROCESS_DT").alias("EFF_DT"))
                .withColumn("END_DT",lit("16-06-2295"));
                //, basecsv.col("PROCESS_DT"));
        leftjoindf.show();

        rightjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "right_outer")
                .filter(basecsv.col("LOAN_NUMBER").isNull())
                .select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE")
                ,deltacsv.col("PROCESS_DT").alias("EFF_DT"))
                 //.withColumn("EFF_DT" , deltacsv.col("PROCESS_DT"))
                .withColumn("END_DT",lit("16-06-2295")) ;
                //,deltacsv.col("PROCESS_DT"));
        rightjoindf.show();
        
        updateddf = leftjoindf.union(innerjoindf.union(rightjoindf));
        System.out.println("The updated dataframe");
        updateddf.show();
    //    updateddf.coalesce(1).write().mode("overwrite").option("header", "true").option("sep", ",").csv("src/main/resources/emptype1/");
		return updateddf;

    }
    
    public static Dataset<Row> scdtype22(String basecsvlocation, String deltacsvlocation) throws IOException {
        SparkSession session = SparkSession
                .builder()
                .appName("SparkJavaExample")
                .master("local")
                .getOrCreate();
        Dataset<Row> basecsv, deltacsv;
        basecsv = session.read().format("csv")
                .option("sep", ",")
                .option("inferSchema", "true")
                .option("header", "true")
                .load("src/main/resources/"+basecsvlocation);
        //   .load("src/main/resources/loan_base_data.csv");
        basecsv.show();
        basecsv.printSchema();

        deltacsv = session.read().format("csv")
                .option("sep", ",")
                .option("inferSchema", "true")
                .option("header", "true")
                .load("src/main/resources/"+deltacsvlocation);
        deltacsv.show();
        deltacsv.printSchema();
        Dataset<Row>  ijupdatedf, ijexistdf, leftjoindf, rightjoindf, updateddf;
        ijupdatedf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "inner")
                .select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                deltacsv.col("PROCESS_DT").alias("EFF_DT"))
                .withColumn("END_DT",lit("16-06-2295"))
                .withColumn("IS_CURRENT",lit("Y"))
                .withColumn("LAST_UPDATE", current_date()); //inner join updated records
        ijupdatedf.show();

        ijexistdf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "inner")
                .select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"), basecsv.col("PRINCIPAL_BALANCE"),
                basecsv.col("PROCESS_DT").alias("EFF_DT"),basecsv.col("PROCESS_DT").alias("END_DT"))
                .withColumn("IS_CURRENT",lit("N"))
                .withColumn("LAST_UPDATE", current_date()); //inner join existing records
        ijexistdf.show();

        leftjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "left_outer")
                .filter(deltacsv.col("LOAN_NUMBER").isNull())
                .select(basecsv.col("LOAN_NUMBER"), basecsv.col("NEXT_PMT_DUE_DATE"),
                basecsv.col("PRINCIPAL_BALANCE"), basecsv.col("PROCESS_DT").alias("EFF_DT"))
                .withColumn("END_DT",lit("16-06-2295"))
                .withColumn("IS_CURRENT",lit("y"))
                .withColumn("LAST_UPDATE", current_date());  //unchanged records
        //.withColumn("Curr_date",lit("Updated"))
        leftjoindf.show();

        rightjoindf = basecsv.join(deltacsv, basecsv.col("LOAN_NUMBER")
                .equalTo(deltacsv.col("LOAN_NUMBER")), "right_outer")
                .filter(basecsv.col("LOAN_NUMBER").isNull())
                .select(deltacsv.col("LOAN_NUMBER"), deltacsv.col("NEXT_PMT_DUE_DATE"), deltacsv.col("PRINCIPAL_BALANCE"),
                deltacsv.col("PROCESS_DT").alias("EFF_DT"))
                .withColumn("END_DT",lit("16-06-2295"))
                .withColumn("IS_CURRENT",lit("y"))
                .withColumn("LAST_UPDATE", current_date()); //new records
        rightjoindf.show();
        updateddf = leftjoindf.union(ijexistdf.union(rightjoindf.union(ijupdatedf)));
        System.out.println("The updated dataframe");
        updateddf.show();
       // updateddf.coalesce(1).write().mode("overwrite").option("header", "true").option("sep", ",").csv("src/main/resources/emptype2/");
		return updateddf;
    }
    
    static Dataset<Row> CsvToDatasetToDataframe(String expectedOutputFile) {
		
		SparkSession spark = SparkSession.builder()
		        .appName("CSV to dataframe to Dataframe and back")
		        .master("local")
		        .getOrCreate();
		
		
		String filename = "src/main/resources/"+expectedOutputFile;
		
		Dataset<Row> df  = spark.read().format("csv")
                .option("sep", ",")
                .option("inferSchema", "true")
                .option("header", "true")
                .load(filename);

	    
	    System.out.println("Expected Output ingested in a dataframe: ");
	
		return df;
	}
    

}
